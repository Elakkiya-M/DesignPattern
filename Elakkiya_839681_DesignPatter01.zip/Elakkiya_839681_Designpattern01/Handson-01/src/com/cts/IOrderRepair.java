package com.cts;

public interface IOrderRepair {

	public void ProcessOrder(String modelName);
	
	public void processPhoneRepair(String modelName);
	
	public void processAccessoryRepair(String accessoryType);
}
