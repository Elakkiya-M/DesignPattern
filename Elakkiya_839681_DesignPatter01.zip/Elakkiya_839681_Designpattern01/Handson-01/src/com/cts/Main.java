package com.cts;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	PhoneOrderRepair por=new PhoneOrderRepair();
		System.out.println("Welcome to our site. Would you like to order or repair ? ");
		Scanner sc=new Scanner(System.in);
	String processOption=sc.nextLine().trim().toLowerCase();
	String productDetail="";
	switch (processOption) {
	case "order":
		System.out.println("Please Provide Phone model name : ");
		productDetail=sc.nextLine();
		por.ProcessOrder(productDetail);
		break;

	case "repair":
		System.out.println("Is it the phone or accessory that you want to be repaired ? ");
		productDetail=sc.nextLine();
		if(productDetail.equals("phone")) {
			System.out.println("Please enter phone model name : ");
			productDetail=sc.nextLine();
			por.processPhoneRepair(productDetail);
		}else if(productDetail.equals("accessory")) {
			System.out.println("Please enter accessory detail, Like headphone, tempered glass : ");
			productDetail=sc.nextLine();
			por.processAccessoryRepair(productDetail);
			
		}else {
			System.out.println("Enter Valid Input!");
		}
		break;
	default:
		System.out.println("Please Enter Valid Input !");
		break;
	}
	
	}

}
