package com.cts2;

public class SamsungNote implements Iphone{

	@Override
	public String getPhonePart1() {
		return "display";
	}

	@Override
	public double getPart1Cost() {
		return 500;
	}

}
