package com.cts2;

public interface Iphone {

	public String getPhonePart1();
	public double getPart1Cost();
	
}
