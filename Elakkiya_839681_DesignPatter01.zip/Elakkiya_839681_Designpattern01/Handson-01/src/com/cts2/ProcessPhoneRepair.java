package com.cts2;

public class ProcessPhoneRepair {

	public void RepairSteps(Iphone iPhone) {
		System.out.println("Repaired " + iPhone.getPhonePart1());
		
		System.out.println("Repaie Cost : " + iPhone.getPart1Cost());
	}
}
