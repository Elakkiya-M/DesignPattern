package com.cts2;

public class RedmiNote7 implements Iphone {

	@Override
	public String getPhonePart1() {
		return "battery";
	}

	@Override
	public double getPart1Cost() {
		return 400;
	}

}
