package com.cts;

public interface IOrder {

	public void ProcessOrder(String modelName);
	
	}
