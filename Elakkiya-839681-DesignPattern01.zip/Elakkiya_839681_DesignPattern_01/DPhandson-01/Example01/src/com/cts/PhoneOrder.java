package com.cts;

public class PhoneOrder implements IOrder{

	@Override
	public void ProcessOrder(String modelName) {
	
		System.out.println("Order Accepted ! "+modelName);
	}

}
