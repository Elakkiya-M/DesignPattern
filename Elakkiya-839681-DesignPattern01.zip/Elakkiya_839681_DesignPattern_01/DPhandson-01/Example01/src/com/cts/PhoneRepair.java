package com.cts;

public class PhoneRepair implements IRepair{

	@Override
	public void processPhoneRepair(String modelName) {
		System.out.println("Repair Accepted ! "+modelName);
			
	}

	@Override
	public void processAccessoryRepair(String accessoryType) {
		System.out.println("Repair Accepted ! "+accessoryType);
		
	}

}
