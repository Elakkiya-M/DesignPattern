package com.cts;

public interface Phone {

	public String getPhonePart1();
	public double getPart1Cost();
	
}
