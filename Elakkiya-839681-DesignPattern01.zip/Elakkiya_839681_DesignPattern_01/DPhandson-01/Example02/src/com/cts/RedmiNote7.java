package com.cts;

public class RedmiNote7 implements Phone {

	@Override
	public String getPhonePart1() {
		return "battery";
	}

	@Override
	public double getPart1Cost() {
		return 400;
	}

}
