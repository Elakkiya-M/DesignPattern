package com.cts;

public class ProcessPhoneRepair {

	public void RepairSteps(Phone iPhone) {
		System.out.println("Repaired " + iPhone.getPhonePart1());
		
		System.out.println("Repaie Cost : " + iPhone.getPart1Cost());
	}
}
